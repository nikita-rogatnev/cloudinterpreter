<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('JOOMAILERMC_VERSION', '1.7.2');
define('JOOMAILERMC_DATE', '2011-06-29');